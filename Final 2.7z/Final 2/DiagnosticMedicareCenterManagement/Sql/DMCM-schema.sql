create database DMCM;
use DMCM;

CREATE TABLE patient(
		pt_id as CAST('PAT'+RIGHT('000'+CAST(pt_RowNum AS Varchar(3)),3) AS Varchar(30)) PERSISTED,
		pt_first_name varchar(50) NOT NULL,
		pt_last_name varchar(50) NOT NULL,
		pt_age numeric(2) NOT NULL,
		pt_gender varchar(10) NULL,
		pt_Dob varchar(10) NULL,
		pt_phone numeric(10) NOT NULL,
		pt_altphone numeric(10) NULL,
		pt_email varchar(50) NOT NULL,
		pt_password varchar(15) NOT NULL,
		pt_address_line1 varchar(100) NOT NULL,
		pt_address_line2 varchar(100) NULL,
		pt_city varchar(50) NOT NULL,
		pt_state varchar(50) NOT NULL,
		pt_zipcode numeric(10) NOT NULL,

		pt_RowNum int IDENTITY(1,1) NOT NULL,
		CONSTRAINT PK_patient PRIMARY KEY(pt_id)
		);

CREATE TABLE doctor(
		do_id as CAST('DOC'+RIGHT('000'+CAST(do_RowNum AS Varchar(3)),3) AS Varchar(30)) PERSISTED,
		do_first_name varchar(50) NOT NULL,
		do_last_name varchar(50) NOT NULL,
		do_age numeric(2) NOT NULL,
		do_gender varchar(10) NULL,
		do_Dob varchar(10) NULL,
		do_phone numeric(10) NOT NULL,
		do_altphone numeric(10) NULL,
		do_email varchar(50) NOT NULL,
		do_password varchar(15) NOT NULL,
		do_address_line1 varchar(100) NOT NULL,
		do_address_line2 varchar(100) NULL,
		do_city varchar(50) NOT NULL,
		do_state varchar(50) NOT NULL,
		do_zipcode numeric(10) NOT NULL,
		do_degree varchar(50) NOT NULL,
		do_speciality varchar(50) NOT NULL,
		do_work_hours numeric(5) NOT NULL,
		do_clinic_name varchar(100) NOT NULL,
		do_medicare_service_id numeric(10),

		do_RowNum int IDENTITY(1,1) NOT NULL,
		CONSTRAINT PK_doctor PRIMARY KEY(do_id)
		);

CREATE TABLE [admin](
		ad_id as CAST('AD'+RIGHT('000'+CAST(ad_RowNum AS Varchar(3)),3) AS Varchar(30)) PERSISTED,
		ad_first_name varchar(50) NOT NULL,
		ad_last_name varchar(50) NOT NULL,
		ad_age numeric(2) NOT NULL,
		ad_gender varchar(10) NOT NULL,
		ad_Dob varchar(10) NOT NULL,
		ad_phone numeric(10) NOT NULL,
		ad_altphone numeric(10) NULL,
		ad_email varchar(50) NOT NULL,
		ad_password varchar(15) NOT NULL,

		ad_RowNum int IDENTITY(1,1) NOT NULL,
		CONSTRAINT PK_admin PRIMARY KEY(ad_id)
		);

CREATE TABLE medicare_services(
		ms_id numeric(10) IDENTITY(1,1) NOT NULL,
		ms_service varchar(50) NOT NULL,
		ms_description varchar(200) NOT NULL,
		ms_amount numeric(10) NOT NULL,
		
		CONSTRAINT PK_medicare PRIMARY KEY(ms_id) 
);

CREATE TABLE medical_test_history(
		mth_id numeric(10) IDENTITY(1,1) NOT NULL,
		mth_pt_id varchar(30),
		mth_do_id varchar(30),
		mth_ms_id numeric(10),
		mth_service_date date NULL,
		mth_test_result_date date NULL,
		mth_diag1_actual_value numeric(10),
		mth_diag1_normal_range numeric(10),
		mth_diag2_actual_value numeric(10) NULL,
		mth_diag2_normal_range numeric(10) NULL,
		mth_diag3_actual_value numeric(10) NULL,
		mth_diag3_normal_range numeric(10) NULL,
		mth_diag4_actual_value numeric(10) NULL,
		mth_diag4_normal_range numeric(10) NULL,
		mth_diag5_actual_value numeric(10) NULL,
		mth_diag5_normal_range numeric(10) NULL,
		mth_diag6_actual_value numeric(10) NULL,
		mth_diag6_normal_range numeric(10) NULL,
		mth_doctors_comments varchar(100) NULL,
		mth_other_info varchar(300) NULL 

		CONSTRAINT PK_test_history PRIMARY KEY(mth_id) 
);


alter table medical_test_history ADD CONSTRAINT mth_pt_id_fk FOREIGN KEY(mth_pt_id) REFERENCES [patient](pt_id) on delete cascade on update cascade;
alter table medical_test_history ADD CONSTRAINT mth_do_id_fk FOREIGN KEY(mth_do_id) REFERENCES [doctor](do_id) on delete cascade on update cascade;
alter table medical_test_history ADD CONSTRAINT mth_ms_id_fk FOREIGN KEY(mth_ms_id) REFERENCES [medicare_services](ms_id) on delete cascade on update cascade;

alter table doctor ADD CONSTRAINT do_ms_id_fk FOREIGN KEY(do_medicare_service_id) REFERENCES [medicare_services](ms_id) on delete no action on update no action;

drop table patient;
drop table doctor;
drop table [admin];
drop table medicare_services;
drop table medical_test_history;
sp_help [patient];
sp_help [doctor];
sp_help [medicare_services];
sp_help [medical_test_history];

ALTER TABLE medical_test_history ALTER COLUMN mth_service_date varchar(10);

 ALTER TABLE medical_test_history ALTER COLUMN mth_test_result_date varchar(10);

 ALTER TABLE [patient] ADD pt_status varchar(10);
 ALTER TABLE [doctor] ADD do_status varchar(10);

  ALTER TABLE [patient] ADD pt_report_status varchar(10);

   ALTER TABLE [patient] ALTER COLUMN pt_report_status varchar(20);

    ALTER TABLE [appointment] ADD ap_rp_status varchar(10);
	 ALTER TABLE [appointment] ALTER COLUMN ap_rp_status varchar(20);
   sp_help appointment;

select * from patient;
select * from [medicare_services](nolock);
select * from [medicare_services](nolock) where ms_id=1;
select * from doctor;
select pt_id,pt_first_name,pt_last_name,mth_service_date,mth_test_result_date from [patient] as pt inner join [medical_test_history] as mth on pt.pt_id=mth.mth_pt_id where mth_do_id='DOC001';
select * from [medical_test_history];
insert into patient values('tony','s',22,'male',22/09/1996,8973364443,8110072333,'jughi@gmail.com','123sfg','dsf','sdf','efsdf','fgsfg',638052,'Inactive','Unavailable');

insert into [medicare_services] values('fjdkls','jkahcjkd sdfiosfjk sdfhd',700);
select * from [medical_test_history];

select pt_id,pt_first_name,pt_last_name,pt_gender,pt_phone from [patient](nolock);
select * from medical_test_history;

UPDATE [patient] SET pt_status='Inactive',pt_report_status='Available' WHERE pt_id='PAT001';
UPDATE [doctor] SET do_status='Inactive' WHERE do_id='DOC002';

CREATE TABLE appointment(

 ap_id numeric(10) IDENTITY(1,1) NOT NULL,

 ap_pt_id varchar(30),

 ap_do_id varchar(30),

 ap_ms_id numeric(10),

 ap_date date,

 ap_status varchar(20)



 CONSTRAINT PK_appointment PRIMARY KEY(ap_id)

);



alter table appointment ADD CONSTRAINT ap_pt_id_fk FOREIGN KEY(ap_pt_id) REFERENCES [patient](pt_id) on delete cascade on update cascade;

alter table appointment ADD CONSTRAINT ap_do_id_fk FOREIGN KEY(ap_do_id) REFERENCES [doctor](do_id) on delete cascade on update cascade;

alter table appointment ADD CONSTRAINT ap_ms_id_fk FOREIGN KEY(ap_ms_id) REFERENCES [medicare_services](ms_id) on delete cascade on update cascade;

select * from [appointment];
select * from patient;
select * from doctor;
select * from [admin];
select * from medical_test_history;
select * from medicare_services;

insert into appointment values('PAT007','DOC001',1,'11/25/2012','Not Approved'),
('PAT006','DOC002',2,'11/26/2012','Not Approved');

UPDATE [appointment] SET ap_ms_id=2 WHERE ap_id=5;

UPDATE [Patient] SET pt_report_status='Available' WHERE pt_id='PAT005';


select pt_id,pt_first_name,pt_last_name,pt_gender,pt_phone,pt_report_status from patient (nolock) pa inner join appointment (nolock) ap on pa.pt_id=ap.ap_pt_id where ap.ap_do_id='DOC001' and ap_status='Approved';

CREATE TABLE report(

 rp_id numeric(10) IDENTITY(1,1) NOT NULL,

 rp_pt_id varchar(30),

 rp_do_id varchar(30),

 rp_status varchar(20)



 CONSTRAINT PK_report PRIMARY KEY(rp_id)

);

alter table report ADD CONSTRAINT rp_pt_id_fk FOREIGN KEY(rp_pt_id) REFERENCES [patient](pt_id) on delete cascade on update cascade;

alter table report ADD CONSTRAINT rp_do_id_fk FOREIGN KEY(rp_do_id) REFERENCES [doctor](do_id) on delete cascade on update cascade;

sp_help report;

alter table patient drop column pt_report_status;

select pt_id,pt_first_name,pt_last_name from [patient] where pt_email ='hello@gmail.com';


Select * from patient

select * from medical_test_history;
select do.medicare_service_id from [doctor] as do where do.do_id = 'DOC002';
update [medical_test_history] set mth_test_result_date='25/09/2019' where mth_pt_id='PAT005' and mth_do_id='DOC002' and mth_service_date='22/09/2019';