﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.dmcm.model;
using com.cognizant.dmcm.dao;
public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            ddlGender.Items.Add("Select Gender");
            ddlGender.Items.Add("Male");
            ddlGender.Items.Add("Female");

            List<string> ageList = new List<string>();
            for (int age = 15; age <= 100; age++)
            {
                ageList.Add(age.ToString());
            }

            ddlAge.DataSource = ageList;
            ddlAge.DataBind();
            ddlAge.Items.Insert(0, "Select Age");

        }
    }

    protected void btnPatientLogin_Click(object sender, EventArgs e)
    {
        try
        {
            int age = 0;
            PatientDaoSqlImpl patientDao = new PatientDaoSqlImpl();
            Patient patient = new Patient();
            patient.FirstName = txtPatientFirstName.Text;
            patient.LastName = txtPatientLastName.Text;
            patient.Age = int.Parse(ddlAge.SelectedItem.Text);
            patient.Gender = ddlGender.SelectedItem.Text;
            patient.DateOfBirth = txtDob.Text;
            DateTime dt = DateTime.ParseExact(txtDob.Text, "dd/MM/yyyy", null);

            age = DateTime.Now.Year - dt.Year;

            if (patient.Age == age)
            {

                patient.Phone = long.Parse(txtPhone.Text);
                if (txtAltPhone.Text == "")
                {
                    patient.AlternatePhone = 0;
                }
                else
                {
                    patient.AlternatePhone = long.Parse(txtAltPhone.Text);
                }
                patient.Email = txtEmail.Text;
                Session["patientEmail"] = patient.Email;
                patient.Password = txtPassword.Text;
                patient.AddressLine1 = txtAddressLine1.Text;
                patient.AddressLine2 = txtAddressLine2.Text;
                patient.City = txtCity.Text;
                patient.State = txtState.Text;
                patient.Zipcode = long.Parse(txtPhone.Text);

                if (patientDao.PatientRegistration(patient) == 1)
                {
                    Response.Write("<script>alert('Registration Successful');window.location.href='GeneratePatientId.aspx'</script>");
                }
                else if (patientDao.PatientRegistration(patient) == 2)
                {
                    Response.Write("<script>alert('Email Already taken.Register with new Email');</script>");
                }
                else if (patientDao.PatientRegistration(patient) == 3)
                {
                    Response.Write("<script>alert('Alternate number should be different');</script>");
                }
                else
                {
                    Response.Write("<script>alert('Registration Failed');window.location.href='PatientRegistration.aspx'</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('Invalid Date of birth and age');</script>");
            }
        }
        catch (Exception)
        {
            Response.Redirect("ErrorPage.aspx");
        }

    }

    protected void btnPatientReset_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Redirect("PatientRegistration.aspx");
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}