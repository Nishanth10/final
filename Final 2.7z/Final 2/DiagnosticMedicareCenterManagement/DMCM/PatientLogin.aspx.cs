﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.dmcm.dao;
using com.cognizant.dmcm.model;
public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            lblMessage.Visible = false;
        }
    }

    protected void btnPatientLogin_Click(object sender, EventArgs e)
    {
        try
        {
            PatientDaoSqlImpl patientDao = new PatientDaoSqlImpl();
            int result = patientDao.PatientLogin(txtPatientId.Text, txtPatientPassword.Text);
            if (result == 1)
            {
                lblMessage.Visible = false;
                lblMessage.Text = "";
                Session["patientId"] = txtPatientId.Text;
                Session["patientName"] = patientDao.GetPatientName(txtPatientId.Text);
                Response.Write("<script>alert('Welcome');window.location.href='Patient.aspx'</script>");
            }
            if (result == 2)
            {
                lblMessage.Visible = false;
                Response.Write("<script>alert('Your Status is still Inactive....Try after 24 Business hours');</script>");
            }
            if (result == 3)
            {
                lblMessage.Visible = true;
                lblMessage.Text = "Invalid Credentials..Try again!!";
                txtPatientId.Text = "";
                txtPatientPassword.Text = "";
                txtPatientId.Focus();
            }
            if (result == 4)
            {
                Response.Write("<script>alert('Unable to login...Your status is rejected');</script>");
            }
        }
        catch (Exception exception)
        {
            Console.WriteLine(exception.Message);
            Response.Redirect("ErrorPage.aspx");
        }

    }
}