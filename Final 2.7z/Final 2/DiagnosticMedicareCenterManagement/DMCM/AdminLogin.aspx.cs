﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.dmcm.dao;

public partial class _Default : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
        if(!IsPostBack) {
            lblMessage.Visible = false;
        }
    }

    protected void btnAdminLogin_Click(object sender, EventArgs e) {
        try
        {
            AdminDaoSqlImpl adminDao = new AdminDaoSqlImpl();
        int result = adminDao.AdminLogin(txtAdminId.Text, txtAdminPassword.Text);
        if (result == 1) {
            lblMessage.Visible = false;
            lblMessage.Text = "";
            Session["adminId"] = txtAdminId.Text;
            Session["adminName"] = adminDao.AdminName(txtAdminId.Text);
            Response.Write("<script>alert('Welcome Admin');window.location.href='AdminPage.aspx'</script>");
           }
        else {
            lblMessage.Visible = true;
            lblMessage.Text = "Invalid Credentials..Try again!!";
            txtAdminId.Text = "";
            txtAdminPassword.Text = "";
            txtAdminId.Focus();
           }
        }
        catch (Exception exception)
        {
            Console.WriteLine(exception.Message);
            Response.Redirect("ErrorPage.aspx");
        }
    }
}