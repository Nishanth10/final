﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.dmcm.dao;
using com.cognizant.dmcm.model;
using com.cognizant.dmcm.util;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ddlGender.Items.Add("Select Gender");
            ddlGender.Items.Add("Male");
            ddlGender.Items.Add("Female");

            List<string> ageList = new List<string>();
            for (int age = 25; age <= 85; age++)
            {
                ageList.Add(age.ToString());
            }
            ddlAge.DataSource = ageList;
            ddlAge.DataBind();
            ddlAge.Items.Insert(0, "Select Age");

            ddlSpeciality.Items.Add("Select Speciality");
            ddlSpeciality.Items.Add("Surgeon");
            ddlSpeciality.Items.Add("Dentist");
            ddlSpeciality.Items.Add("ENT");
            ddlSpeciality.Items.Add("Eye Specialist");
            ddlSpeciality.Items.Add("Child Specialist");

            List<string> workHoursList = new List<string>();
            for (int workHours = 1; workHours <= 12; workHours++)
            {
                workHoursList.Add(workHours.ToString());
            }
            ddlWorkHours.DataSource = workHoursList;
            ddlWorkHours.DataBind();
            ddlWorkHours.Items.Insert(0, "Select Work Hours");

            ddlClinic.Items.Add("Select Clinic");
            ddlClinic.Items.Add("Appolo Hospital");
            ddlClinic.Items.Add("Sindhu Hospital");
            ddlClinic.Items.Add("Ganga Hospital");
            ddlClinic.Items.Add("Lotus Hospital");
            ddlClinic.Items.Add("Vasan Eye Care");
        }
    }


    protected void BtnDoctorRegister_Click(object sender, EventArgs e)
    {
        try
        {
            int age = 0;
            DoctorDaoSqlImpl doctorDao = new DoctorDaoSqlImpl();
            Doctor doctor = new Doctor();
            doctor.FirstName = txtFirstName.Text;
            doctor.LastName = txtLastName.Text;
            doctor.Age = int.Parse(ddlAge.SelectedItem.Text);
            doctor.Gender = ddlGender.SelectedItem.Text;
            doctor.DateOfBirth = txtDob.Text;
            DateTime dt= DateTime.ParseExact(txtDob.Text,"dd/MM/yyyy",null);

            age = DateTime.Now.Year - dt.Year;

           // Response.Write(age);
             
           if(doctor.Age==age)
            {
                //doctor.Age = int.Parse(ddlAge.SelectedItem.Text);
                doctor.Phone = long.Parse(txtPhone.Text);
                if (txtAltPhone.Text == "")
                {
                    doctor.AlternatePhone = 0;
                }
                else
                {
                    doctor.AlternatePhone = long.Parse(txtAltPhone.Text);
                }

                doctor.Email = txtEmail.Text;
                Session["email"] = doctor.Email;
                doctor.Password = txtPwd.Text;
                doctor.AddressLine1 = txtAdrs1.Text;
                doctor.AddressLine2 = txtAdrs2.Text;
                doctor.City = txtCity.Text;
                doctor.State = txtState.Text;
                doctor.Zipcode = long.Parse(txtZipCode.Text);
                doctor.Degree = txtDegree.Text;
                doctor.Speciality = ddlSpeciality.SelectedItem.Text;
                doctor.WorkHours = long.Parse(ddlWorkHours.SelectedItem.Text);
                doctor.ClinicName = ddlClinic.SelectedItem.Text;



                if (doctorDao.DoctorRegistration(doctor) == 1)
                {
                    Response.Write("<script>alert('Registration Successful');window.location.href='GenerateId.aspx'</script>");
                }
                else if (doctorDao.DoctorRegistration(doctor) == 2)
                {
                    Response.Write("<script>alert('Email Already taken.Register with new Email');</script>");
                }
                else if (doctorDao.DoctorRegistration(doctor) == 3)
                {
                    Response.Write("<script>alert('Alternate number should be different');</script>");
                }
                else
                {
                    Response.Write("<script>alert('Registration Failed');window.location.href='DoctorRegistration.aspx'</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('Invalid Date of birth and age');</script>");
            }
            
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }


}

protected void btnDoctorReset_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Redirect("DoctorRegistration.aspx");
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}