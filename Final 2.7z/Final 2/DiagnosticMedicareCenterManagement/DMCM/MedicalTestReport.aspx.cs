﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.dmcm.dao;
using com.cognizant.dmcm.model;
using com.cognizant.dmcm.util;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtDoctorId.Text = Session["doctorId"].ToString();
            txtPatientId.Text = Session["patientId"].ToString();
            string date = Session["apDate"].ToString();
            DateTime apDate = DateTime.Parse(date);
            txtServiceDate.Text = apDate.ToString("dd/MM/yyyy");
        }
    }

    protected void BtnReportSave_Click(object sender, EventArgs e)
    {
        try
        {
            MedicalHistoryDaoSqlImpl medicalTestHistoryDao = new MedicalHistoryDaoSqlImpl();
            DoctorDaoSqlImpl doctorDao = new DoctorDaoSqlImpl();
            MedicalTestHistory medicalTestHistory = new MedicalTestHistory();
            medicalTestHistory.PatientId = txtPatientId.Text;
            medicalTestHistory.DoctorId = txtDoctorId.Text;
            int medicareServiceId = doctorDao.GetDoctorMedicareId(txtDoctorId.Text);
            medicalTestHistory.MedicareServiceId = medicareServiceId;
            medicalTestHistory.ServiceDate = txtServiceDate.Text;
            medicalTestHistory.TestResultDate = txtTestResultDate.Text;
            medicalTestHistory.Diag1ActualValue = long.Parse(txtDiag1Actual.Text);
            medicalTestHistory.Diag1NormalRange = long.Parse(TxtDiag1Normal.Text);
            if (txtDiag2Actual.Text == "")
            {
                medicalTestHistory.Diag2ActualValue = 0;
            }
            else
            {
                medicalTestHistory.Diag2ActualValue = long.Parse(txtDiag2Actual.Text);
            }
            if (txtDiag2Normal.Text == "")
            {
                medicalTestHistory.Diag2NormalRange = 0;
            }
            else
            {
                medicalTestHistory.Diag2NormalRange = long.Parse(txtDiag2Normal.Text);
            }


            if (txtDiag3Actual.Text == "")
            {
                medicalTestHistory.Diag3ActualValue = 0;
            }
            else
            {
                medicalTestHistory.Diag3ActualValue = long.Parse(txtDiag3Actual.Text);
            }
            if (txtDiag3Normal.Text == "")
            {
                medicalTestHistory.Diag3NormalRange = 0;
            }
            else
            {
                medicalTestHistory.Diag3NormalRange = long.Parse(txtDiag3Normal.Text);
            }


            if (txtDiag4Actual.Text == "")
            {
                medicalTestHistory.Diag4ActualValue = 0;
            }
            else
            {
                medicalTestHistory.Diag4ActualValue = long.Parse(txtDiag4Actual.Text);
            }
            if (txtDiag4Normal.Text == "")
            {
                medicalTestHistory.Diag4NormalRange = 0;
            }
            else
            {
                medicalTestHistory.Diag4NormalRange = long.Parse(txtDiag4Normal.Text);
            }


            if (txtDiag5Actual.Text == "")
            {
                medicalTestHistory.Diag5ActualValue = 0;
            }
            else
            {
                medicalTestHistory.Diag5ActualValue = long.Parse(txtDiag5Actual.Text);
            }
            if (txtDiag5Normal.Text == "")
            {
                medicalTestHistory.Diag5NormalRange = 0;
            }
            else
            {
                medicalTestHistory.Diag5NormalRange = long.Parse(txtDiag5Normal.Text);
            }


            if (txtDiag6Actual.Text == "")
            {
                medicalTestHistory.Diag6ActualValue = 0;
            }
            else
            {
                medicalTestHistory.Diag6ActualValue = long.Parse(txtDiag6Actual.Text);
            }
            if (txtDiag6Normal.Text == "")
            {
                medicalTestHistory.Diag6NormalRange = 0;
            }
            else
            {
                medicalTestHistory.Diag6NormalRange = long.Parse(txtDiag6Normal.Text);
            }

            medicalTestHistory.DoctorComments = txtDocComments.Text;
            medicalTestHistory.OtherInfo = txtOtherInfo.Text;

            if (medicalTestHistoryDao.AddMedicalHistory(medicalTestHistory) == 1)
            {
                PatientDaoSqlImpl patientDao = new PatientDaoSqlImpl();
                patientDao.UpdateReportStatus(txtPatientId.Text,txtDoctorId.Text);
                Response.Write("<script>alert('Saved Succesfully');window.location.href='DoctorPage.aspx'</script>");
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

    protected void btnTestReset_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Redirect("MedicalTestReport.aspx");
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

    protected void btnBack_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Redirect("DoctorPage.aspx");
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}