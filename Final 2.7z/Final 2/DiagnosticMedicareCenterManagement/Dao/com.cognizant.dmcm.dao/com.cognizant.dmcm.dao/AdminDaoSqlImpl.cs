﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using com.cognizant.dmcm.model;

namespace com.cognizant.dmcm.dao {
    public class AdminDaoSqlImpl : IAdminDao {
        static string _callConnection = ConnectionHandler.ConnectionVariable;

        public int AdminRegistration(Admin admin) {
            int result = 0;
            int checkEmail = 0;
            using (SqlConnection connection = new SqlConnection(_callConnection)) {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._registerAdmin
                };

                sqlCommand.Parameters.Add(ConstantsImpl._firstName, SqlDbType.VarChar).Value = admin.FirstName;
                sqlCommand.Parameters.Add(ConstantsImpl._lastName, SqlDbType.VarChar).Value = admin.LastName;
                sqlCommand.Parameters.Add(ConstantsImpl._age, SqlDbType.Int).Value = admin.Age;
                sqlCommand.Parameters.Add(ConstantsImpl._gender, SqlDbType.VarChar).Value = admin.Gender;
                sqlCommand.Parameters.Add(ConstantsImpl._dob, SqlDbType.VarChar).Value = admin.DateOfBirth;
                sqlCommand.Parameters.Add(ConstantsImpl._phone, SqlDbType.BigInt).Value = admin.Phone;
                if (admin.AlternatePhone == 0) {
                    sqlCommand.Parameters.Add(ConstantsImpl._alternatePhone, SqlDbType.BigInt).Value = 0;
                }
                else if (admin.Phone == admin.AlternatePhone)
                {
                    result = 3;
                    return result;
                }
                else {
                    sqlCommand.Parameters.Add(ConstantsImpl._alternatePhone, SqlDbType.BigInt).Value = admin.AlternatePhone;
                }
                checkEmail = GetMail(admin.Email);
                if (checkEmail == 1)
                {
                    result = 2;
                    return result;
                }
                else
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._email, SqlDbType.VarChar).Value = admin.Email;
                }
                sqlCommand.Parameters.Add(ConstantsImpl._password, SqlDbType.VarChar).Value = admin.Password;

                result = sqlCommand.ExecuteNonQuery();
            }
            return result;
        }

        public int GetMail(string email)
        {
            int result = 0;
            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._getAdminEmail
                };

                SqlDataReader dataReader = sqlCommand.ExecuteReader();
                while (dataReader.Read())
                {
                    if (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._adminEmail))).Equals(email))
                    {
                        result = 1;
                        break;
                    }
                }
            }
            return result;
        }

        public int AdminLogin(string adminId, string password) {
            int logResult = 0;
            using (SqlConnection connection = new SqlConnection(_callConnection)) {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._loginAdmin
                };

                SqlDataReader dataReader = sqlCommand.ExecuteReader();
                while (dataReader.Read()) {
                    if (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._adminId))).Equals(adminId)
                        && Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._adminPassword))).Equals(password)) {
                        logResult = 1;
                        break;
                    }
                    else {
                        logResult = 2;
                    }
                }
            }
            return logResult;
        }

        public string AdminName(string adminId) {
            string name = "";
            using (SqlConnection connection = new SqlConnection(_callConnection)) {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._adminName
                };
                sqlCommand.Parameters.Add(ConstantsImpl._id, SqlDbType.VarChar).Value = adminId;
                SqlDataReader dataReader = sqlCommand.ExecuteReader();
                while (dataReader.Read()) {
                    name = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._adminFirstName)))+" "+ Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._adminLastName)));
                }
            }
            return name;
        }
    }
}
