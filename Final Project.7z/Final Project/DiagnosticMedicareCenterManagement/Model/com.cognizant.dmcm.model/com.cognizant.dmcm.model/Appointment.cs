﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.cognizant.dmcm.model {
    public class Appointment:Doctor {
        private int _appointmentId;
        private DateTime _appointmentDate;
        private string _status;
        private string _reportStatus;

        public Appointment() {

        }

        public Appointment(int _appointmentId,DateTime _appointmentDate, string _status,string _reportStatus) {
            this._appointmentId = _appointmentId;
            this._appointmentDate = _appointmentDate;
            this._status = _status;
            this._reportStatus = _reportStatus;
        }

        public int AppointmentId {
            get {
                return _appointmentId;
            }

            set {
                _appointmentId = value;
            }
        }

        public DateTime AppointmentDate {
            get {
                return _appointmentDate;
            }

            set {
                _appointmentDate = value;
            }
        }

        public string Status {
            get {
                return _status;
            }

            set {
                _status = value;
            }
        }

        public string ReportStatus
        {
            get
            {
                return _reportStatus;
            }

            set
            {
                _reportStatus = value;
            }
        }
    }
}
