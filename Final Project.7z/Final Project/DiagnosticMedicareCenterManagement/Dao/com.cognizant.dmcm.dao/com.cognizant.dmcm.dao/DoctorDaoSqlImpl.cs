﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using com.cognizant.dmcm.model;

namespace com.cognizant.dmcm.dao
{
   public class DoctorDaoSqlImpl : IDoctorDao
    {
        static string _callConnection = ConnectionHandler.ConnectionVariable;

        public int DoctorRegistration(Doctor doctor)
        {
            int result = 0;
            int checkEmail = 0;
            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._registerDoctor
                };

                sqlCommand.Parameters.Add(ConstantsImpl._firstName, SqlDbType.VarChar).Value = doctor.FirstName;
                sqlCommand.Parameters.Add(ConstantsImpl._lastName, SqlDbType.VarChar).Value = doctor.LastName;
                sqlCommand.Parameters.Add(ConstantsImpl._age, SqlDbType.Int).Value = doctor.Age;
                sqlCommand.Parameters.Add(ConstantsImpl._gender, SqlDbType.VarChar).Value = doctor.Gender;
                sqlCommand.Parameters.Add(ConstantsImpl._dob, SqlDbType.VarChar).Value = doctor.DateOfBirth;
                sqlCommand.Parameters.Add(ConstantsImpl._phone, SqlDbType.BigInt).Value = doctor.Phone;
                if (doctor.AlternatePhone == 0)
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._alternatePhone, SqlDbType.BigInt).Value = 0;
                }
                else if(doctor.Phone == doctor.AlternatePhone)
                {
                    result = 3;
                    return result;
                }
                else
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._alternatePhone, SqlDbType.BigInt).Value = doctor.AlternatePhone;
                }
                checkEmail = GetMail(doctor.Email);
                if (checkEmail == 1)
                {
                    result = 2;
                    return result;
                }
                else
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._email, SqlDbType.VarChar).Value = doctor.Email;
                }
                sqlCommand.Parameters.Add(ConstantsImpl._password, SqlDbType.VarChar).Value = doctor.Password;
                sqlCommand.Parameters.Add(ConstantsImpl._address_line1, SqlDbType.VarChar).Value = doctor.AddressLine1;
                sqlCommand.Parameters.Add(ConstantsImpl._address_line2, SqlDbType.VarChar).Value = doctor.AddressLine2;
                sqlCommand.Parameters.Add(ConstantsImpl._city, SqlDbType.VarChar).Value = doctor.City;
                sqlCommand.Parameters.Add(ConstantsImpl._state, SqlDbType.VarChar).Value = doctor.State;
                sqlCommand.Parameters.Add(ConstantsImpl._zipcode, SqlDbType.BigInt).Value = doctor.Zipcode;
                sqlCommand.Parameters.Add(ConstantsImpl._degree, SqlDbType.VarChar).Value = doctor.Degree;
                sqlCommand.Parameters.Add(ConstantsImpl._speciality, SqlDbType.VarChar).Value = doctor.Speciality;
                doctor.MedicareServiceId = GetMedicareServiceId(doctor.Speciality);
                sqlCommand.Parameters.Add(ConstantsImpl._workHours, SqlDbType.BigInt).Value = doctor.WorkHours;
                sqlCommand.Parameters.Add(ConstantsImpl._clinicName, SqlDbType.VarChar).Value = doctor.ClinicName;
                sqlCommand.Parameters.Add(ConstantsImpl._medicareServiceId, SqlDbType.BigInt).Value = doctor.MedicareServiceId;
                sqlCommand.Parameters.Add(ConstantsImpl._doctorStatus, SqlDbType.VarChar).Value = "Inactive";

                result = sqlCommand.ExecuteNonQuery();
            }
            return result;
        }

        public int GetMedicareServiceId(string speciality)
        {
            int medicareServiceId = 0;
            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._getMedicareServiceId
                };
                sqlCommand.Parameters.Add(ConstantsImpl._speciality, SqlDbType.VarChar).Value = speciality;

                SqlDataReader dataReader = sqlCommand.ExecuteReader();
                while (dataReader.Read())
                {
                    medicareServiceId = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._medicareServiceTableId)));
                }
            }
            return medicareServiceId;
        }

        public int GetMail(string email)
        {
            int result = 0;
            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._getDoctorEmail
                };

                SqlDataReader dataReader = sqlCommand.ExecuteReader();
                while (dataReader.Read())
                {
                    if(Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doEmail))).Equals(email))
                    {
                        result = 1;
                        break;
                    }
                }
            }
            return result;
        }

        public int GetDoctorMedicareId(string doctorId)
        {
            int medicareServiceId = 0;
            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._getMedicareId
                };
                sqlCommand.Parameters.Add(ConstantsImpl._doId, SqlDbType.VarChar).Value = doctorId;

                SqlDataReader dataReader = sqlCommand.ExecuteReader();
                while (dataReader.Read())
                {
                    medicareServiceId = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doMsId)));
                }
            }
            return medicareServiceId;
        }

        public int DoctorLogin(string doctorId, string password)
        {
            int logResult = 0;
            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._loginDoctor
                };
                sqlCommand.Parameters.Add(ConstantsImpl._id, SqlDbType.VarChar).Value = doctorId;
                SqlDataReader dataReader = sqlCommand.ExecuteReader();
                while (dataReader.Read())
                {
                    if (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doctorId))).Equals(doctorId)
                        && Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doctorPassword))).Equals(password)
                        && Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doctorStatusTable))).
                    Equals(ConstantsImpl._approveValue, StringComparison.InvariantCultureIgnoreCase))
                    {
                        logResult = 1;
                        break;
                    }
                    else if (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doctorId))).Equals(doctorId)
                        && Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doctorPassword))).Equals(password)
                         && Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doctorStatusTable))).
                    Equals(ConstantsImpl._stringInactive, StringComparison.InvariantCultureIgnoreCase))
                    {
                        logResult = 2;
                    }
                    else if (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doctorId))).Equals(doctorId)
                        && Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doctorPassword))).Equals(password)
                         && Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doctorStatusTable))).
                    Equals(ConstantsImpl._rejectValue, StringComparison.InvariantCultureIgnoreCase))
                    {
                        logResult = 4;
                    }
                    else
                    {
                        logResult = 3;
                    }
                }
            }
            return logResult;
        }

        public List<Doctor> DisplayDoctor()
        {
            List<Doctor> doctorList = new List<Doctor>();

            using (SqlConnection con = new SqlConnection(_callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._doctorList
                };

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    Doctor doctor = new Doctor();
                    doctor.DoctorId = Convert.ToString(dr.GetValue(dr.GetOrdinal("do_id")));
                    doctor.FirstName = Convert.ToString(dr.GetValue(dr.GetOrdinal("do_first_name")));
                    doctor.LastName = Convert.ToString(dr.GetValue(dr.GetOrdinal("do_last_name")));
                    doctor.DoctorStatus = Convert.ToString(dr.GetValue(dr.GetOrdinal("do_status")));
                    doctorList.Add(doctor);
                }
                return doctorList;
            }
        }

        public int DoctorStatusApprove(Doctor doctor)
        {
            int result = 0;
            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._updateDoctorStatus
                };

                sqlCommand.Parameters.Add(ConstantsImpl._id, SqlDbType.VarChar).Value = doctor.DoctorId;
                if (doctor.DoctorStatus == "Inactive" || doctor.DoctorStatus == "Rejected")
                {
                    result = 1;
                    sqlCommand.Parameters.Add(ConstantsImpl._doctorStatus, SqlDbType.VarChar).Value = "Approved";
                    sqlCommand.ExecuteNonQuery();
                }
                else
                {
                    result = 2;
                }
                return result;
            }
        }

        public int DoctorStatusReject(Doctor doctor)
        {
            int result = 0;
            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._updateDoctorStatus
                };
                sqlCommand.Parameters.Add(ConstantsImpl._id, SqlDbType.VarChar).Value = doctor.DoctorId;
                if (doctor.DoctorStatus == "Approved" || doctor.DoctorStatus == "Inactive")
                {
                    result = 1;
                    sqlCommand.Parameters.Add(ConstantsImpl._doctorStatus, SqlDbType.VarChar).Value = "Rejected";
                    sqlCommand.ExecuteNonQuery();
                }
                else
                {
                    result = 2;
                }
                return result;
            }
        }

        public Doctor DisplaySpecficDoctorById(string id)
        {
            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._displayFilteredDoctorByID
                };
                sqlCommand.Parameters.Add(ConstantsImpl._id, SqlDbType.VarChar).Value = id;
                SqlDataReader dr = sqlCommand.ExecuteReader();
                Doctor doctor = new Doctor();
                while (dr.Read())
                {
                    doctor.DoctorId = Convert.ToString(dr.GetValue(dr.GetOrdinal("do_id")));
                    doctor.FirstName = Convert.ToString(dr.GetValue(dr.GetOrdinal("do_first_name")));
                    doctor.LastName = Convert.ToString(dr.GetValue(dr.GetOrdinal("do_last_name")));
                    doctor.Age = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("do_age")));
                    doctor.Gender = Convert.ToString(dr.GetValue(dr.GetOrdinal("do_gender")));
                    doctor.DateOfBirth = Convert.ToString(dr.GetValue(dr.GetOrdinal("do_Dob")));
                    doctor.Phone = Convert.ToInt64(dr.GetValue(dr.GetOrdinal("do_phone")));
                    doctor.AlternatePhone = Convert.ToInt64(dr.GetValue(dr.GetOrdinal("do_altphone")));
                    doctor.Email = Convert.ToString(dr.GetValue(dr.GetOrdinal("do_email")));
                    doctor.Password = Convert.ToString(dr.GetValue(dr.GetOrdinal("do_password")));
                    doctor.AddressLine1 = Convert.ToString(dr.GetValue(dr.GetOrdinal("do_address_line1")));
                    doctor.AddressLine2 = Convert.ToString(dr.GetValue(dr.GetOrdinal("do_address_line2")));
                    doctor.City = Convert.ToString(dr.GetValue(dr.GetOrdinal("do_city")));
                    doctor.State = Convert.ToString(dr.GetValue(dr.GetOrdinal("do_state")));
                    doctor.Zipcode = Convert.ToInt64(dr.GetValue(dr.GetOrdinal("do_zipcode")));
                    doctor.Degree = Convert.ToString(dr.GetValue(dr.GetOrdinal("do_degree")));
                    doctor.Speciality = Convert.ToString(dr.GetValue(dr.GetOrdinal("do_speciality")));
                    doctor.WorkHours = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("do_work_hours")));
                    doctor.ClinicName = Convert.ToString(dr.GetValue(dr.GetOrdinal("do_clinic_name")));
                    doctor.MedicareServiceId = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("do_medicare_service_id")));
                }
                return doctor;
            }
        }

        public Doctor GetDoctor(string doctorId)
        {
            Doctor doctor = new Doctor();
            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._getDoctorById
                };
                sqlCommand.Parameters.Add(ConstantsImpl._doId, SqlDbType.VarChar).Value = doctorId;

                SqlDataReader dataReader = sqlCommand.ExecuteReader();

                while (dataReader.Read())
                {
                    doctor.DoctorId = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doctorId)));
                    doctor.FirstName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doFirstName)));
                    doctor.LastName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doLastName)));
                    doctor.Speciality = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doSpeciality)));
                    doctor.Phone = Convert.ToInt64(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doPhone)));
                    doctor.Email = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doEmail)));
                    doctor.WorkHours = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doWorkHours)));
                    doctor.MedicareServiceId = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doMsId)));
                }
            }
            return doctor;
        }

        public List<Doctor> GetDoctorList()
        {
            List<Doctor> doctorList = new List<Doctor>();
            int count = 0;
            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._getDoctor
                };

                SqlDataReader dataReader = sqlCommand.ExecuteReader();
                while (dataReader.Read())
                {
                    Doctor doctor = new Doctor();
                    doctor.DoctorId = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doctorId)));
                    doctor.FirstName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doFirstName)));
                    doctor.LastName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doLastName)));
                    doctor.Speciality = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doSpeciality)));
                    doctor.Phone = Convert.ToInt64(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doPhone)));

                    count++;
                    doctorList.Add(doctor);
                }

                if (count == 0)
                {
                    throw new AppointmentEmptyException("No Record to Display");
                }
            }
            return doctorList;
        }

        public string GetDoctorName(string doctorId)
        {
            string doctorName = "";
            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._getDoctorName
                };

                sqlCommand.Parameters.Add(ConstantsImpl._doId, SqlDbType.VarChar).Value = doctorId;

                SqlDataReader dataReader = sqlCommand.ExecuteReader();
                while (dataReader.Read())
                {
                    doctorName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doFirstName))) + " " + Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doLastName)));
                }
            }
            return doctorName;
        }

        public Doctor DisplaySpecificDoctor(string email)
        {
            Doctor doctor = new Doctor();
            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._displayFilteredUser
                };
                sqlCommand.Parameters.Add(ConstantsImpl._email, SqlDbType.VarChar).Value = email;
                SqlDataReader dataReader = sqlCommand.ExecuteReader();

                while (dataReader.Read())
                {
                    doctor.DoctorId = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doctorId)));
                    doctor.FirstName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doFirstName)));
                    doctor.LastName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doLastName)));
                }
                return doctor;
            }

        }

    }
}
