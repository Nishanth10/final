﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using com.cognizant.dmcm.model;

namespace com.cognizant.dmcm.dao {
    public class AppointmentDaoSqlImpl : IAppointmentDao {
        static string _callConnection = ConnectionHandler.ConnectionVariable;

        public int BookAppointment(string patientId,string doctorId,Appointment appointment) {
            int result = 0;
            using (SqlConnection connection = new SqlConnection(_callConnection)) {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._bookAppointment
                };

                sqlCommand.Parameters.Add(ConstantsImpl._ptId,SqlDbType.VarChar).Value = patientId;
                sqlCommand.Parameters.Add(ConstantsImpl._doId,SqlDbType.VarChar).Value = doctorId;
                sqlCommand.Parameters.Add(ConstantsImpl._medicareServiceId,SqlDbType.BigInt).Value = appointment.MedicareServiceId;
                sqlCommand.Parameters.Add(ConstantsImpl._date,SqlDbType.Date).Value = appointment.AppointmentDate;
                sqlCommand.Parameters.Add(ConstantsImpl._status, SqlDbType.VarChar).Value = "Not Approved";
                sqlCommand.Parameters.Add(ConstantsImpl._reportStatus, SqlDbType.VarChar).Value = "Not Available";

                result = sqlCommand.ExecuteNonQuery();
            }
            return result;
        }

        public int CheckAppointment(DateTime appointmentDate,string patientId,string doctorId) {
            int result = 1;
            using (SqlConnection connection = new SqlConnection(_callConnection)) {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._checkDate
                };

                sqlCommand.Parameters.Add(ConstantsImpl._ptId, SqlDbType.VarChar).Value = patientId;
                sqlCommand.Parameters.Add(ConstantsImpl._doId, SqlDbType.VarChar).Value = doctorId;

                SqlDataReader dataReader = sqlCommand.ExecuteReader();
                while (dataReader.Read()) {
                    Appointment appointment = new Appointment();
                    appointment.AppointmentDate = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._apDate)));
                    if(appointment.AppointmentDate == appointmentDate) {
                        result = 0;
                    }
                    if(result == 0) {
                        break;
                    }
                } 
            }
            return result;
        }

        /*public DataSet ViewDoctorAppointments(string doctorId)
        {
            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._viewDoctorAppointment
                };

                sqlCommand.Parameters.Add(ConstantsImpl._doId, SqlDbType.VarChar).Value = doctorId;

                SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlCommand);
                DataSet dataSet = new DataSet();
                dataAdapter.Fill(dataSet);

                return dataSet;
            }
        }*/

        public List<Patient> ViewDoctorAppointments(string doctorId) {
            int count = 0;
            using (SqlConnection connection = new SqlConnection(_callConnection)) {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._viewDoctorAppointment
                };

                sqlCommand.Parameters.Add(ConstantsImpl._doId, SqlDbType.VarChar).Value = doctorId;

                List<Patient> patientList = new List<Patient>();
            
                SqlDataReader dataReader = sqlCommand.ExecuteReader();
                while (dataReader.Read()) {
                    Patient patient = new Patient();
                    patient.PatientId = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._patientId)));
                    patient.FirstName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._ptFirstName)));
                    patient.LastName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._ptLastName)));
                    patient.AppointmentDate = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._apDate)));
                    patient.Status = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._apStatus)));
                    count++;

                    patientList.Add(patient);
                }
                if (count == 0) {
                    throw new AppointmentEmptyException("No Record to Display");
                }
                return patientList;
            }
        }

        public int ModifyAppointmentStatus(string reportStatus,string status,string patientId,string doctorId,DateTime date ) {
            int result = 0;
            using (SqlConnection connection = new SqlConnection(_callConnection)) {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._updateStatus
                };

                sqlCommand.Parameters.Add(ConstantsImpl._date, SqlDbType.VarChar).Value = date;
                sqlCommand.Parameters.Add(ConstantsImpl._status, SqlDbType.VarChar).Value = status;
                sqlCommand.Parameters.Add(ConstantsImpl._reportStatus, SqlDbType.VarChar).Value = reportStatus;
                sqlCommand.Parameters.Add(ConstantsImpl._ptId, SqlDbType.VarChar).Value = patientId;
                sqlCommand.Parameters.Add(ConstantsImpl._doId, SqlDbType.VarChar).Value = doctorId;


                result=sqlCommand.ExecuteNonQuery();
            }
            return result;
        }

        /* public DataSet ViewPatientAppointments(string patientId)
         {
             using (SqlConnection connection = new SqlConnection(_callConnection))
             {
                 connection.Open();
                 SqlCommand sqlCommand = new SqlCommand
                 {
                     Connection = connection,
                     CommandType = CommandType.Text,
                     CommandText = QueriesImpl._viewPatientAppointment
                 };

                 sqlCommand.Parameters.Add(ConstantsImpl._ptId, SqlDbType.VarChar).Value = patientId;

                 SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlCommand);
                 DataSet dataSet = new DataSet();
                 dataAdapter.Fill(dataSet);

                 return dataSet;
             }
         } */

        public List<Appointment> ViewPatientAppointments(string patientId) {
            int count = 0;
            using (SqlConnection connection = new SqlConnection(_callConnection)) {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._viewPatientAppointment
                };

                sqlCommand.Parameters.Add(ConstantsImpl._ptId, SqlDbType.VarChar).Value = patientId;

                List<Appointment> appointmentList = new List<Appointment>();

                SqlDataReader dataReader = sqlCommand.ExecuteReader();
                while(dataReader.Read()) {
                    Appointment appointment = new Appointment();
                    appointment.FirstName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doFirstName)));
                    appointment.LastName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doLastName)));
                    appointment.AppointmentDate = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._apDate)));
                    appointment.Status = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._apStatus)));
                    count++;

                    appointmentList.Add(appointment);
                }
                if(count == 0) {
                    throw new AppointmentEmptyException("No Record to Display");
                }

                return appointmentList;
            }
          
        }
    }
}
