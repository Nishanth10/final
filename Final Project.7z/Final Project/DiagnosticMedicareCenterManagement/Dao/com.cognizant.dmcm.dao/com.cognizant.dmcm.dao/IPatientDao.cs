﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.dmcm.model;
namespace com.cognizant.dmcm.dao
{
    interface IPatientDao
    {
        int PatientRegistration(Patient patient);
        int PatientLogin(string patientId, string password);
    }
}
